Getting Kline from Binance
